// Copyright (c) Hayden Smith
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
#include <iostream>

int main() {
	int num1 = 5;
	int num2 = 4;
	std::cout << (num1 + num2) << "\n";
}
